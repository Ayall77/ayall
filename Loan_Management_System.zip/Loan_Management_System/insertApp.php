<?php
   //validate customer fields from the form
   //check if required fields are present in customer
   if (($_POST['FirstName']== "")|| ($_POST['LastName']== "")||
              ($_POST['PostCode']  == "") || ($_POST['Dob'] == "")){
           header("Location: applicationForm.html");
           exit;
    }
   //check if postcode has four characters
           if (strlen ( $_POST['PostCode']) != 4)
           {
           header("Location: applicationForm.html");
           exit;
    }
   if (is_numeric ($_POST['PostCode'])){
           settype($_POST['PostCode'], "integer");
           } else {
           header("Location: applicationForm.html");
           exit;
     }
   //validate application fields from the form
           if (($_POST['InterestRate'] == "")|| ($_POST['LoanDuration'] == "")|| 
              ($_POST['LoanValue'] == ""))    {
           header("Location: applicationForm.html");
           exit;
           }
   //validate fields for vehicle
           if (($_POST['VehicleRego'] == ""))
           {
           header("Location: applicationForm.html");
           exit;
           }
   //connect to server and select database
           $conn = mysql_connect("localhost", "", "") or die(mysql_error());
   //pick the database to use
           mysql_select_db("eloan",$conn) or die(mysql_error());
   //insert data into customer
           $insert = "insert into customer (FirstName, LastName, Street,
                  Suburb, City, State, PostCode, Dob) 
           values('$_POST[FirstName]', '$_POST[LastName]','$_POST[Street]','$_POST[Suburb]',
               '$_POST[City]','$_POST[State]', '$_POST[PostCode]','$_POST[Dob]')";
   if (mysql_query($insert, $conn)){
           //retrieve customerid
           $cid = mysql_insert_id($conn);
           }else {
           die(mysql_error());
           }
   //insert data into loanapp
   $insert = "insert into LoanApp (CustomerId, MonthlyIncome,
           MonthlyExpenditure, MonthlyDispIncome, Liabilities,
           TotalAssets, Liquidity, ReqLoadValue, CRAR,
           ExecApproval, DateAccpt, VehicleRego,
           InterestRate, LoanDuration, LoanValue)
           values
           ('$cid', '$_POST[MonthlyIncome]',
           '$_POST[MonthlyExpenditure]','$_POST[MonthlyDispIncome]', '$_POST[Liabilities]',
           '$_POST[TotalAssets]','$_POST[Liquidity]','$_POST[ReqLoadValue]',
           '$_POST[CRAR]', '$_POST[ExecApproval]','$_POST[DateAccpt]',
           '$_POST[VehicleRego]','$_POST[InterestRate]','$_POST[LoanDuration]',
           '$_POST[LoanValue]')";
   if (mysql_query($insert, $conn)){
           //echo "record added!";
           $aid = mysql_insert_id($conn);
           }else {
           die(mysql_error());
           }
   //insert data into vehicld
           $insert = "insert into vehicle (VehicleRego, Make, Model, ModelYear,
           PurchasePrice,ValuationReq,ApplicationID)
           values('$_POST[VehicleRego]', '$_POST[Make]', '$_POST[Model]','$_POST[ModelYear]',
           '$_POST[PurchasePrice]',�� '$_POST[ValuationReq]','$aid')";
  if (mysql_query($insert, $conn)){
           //echo "record added!";
           }else {
           die(mysql_error());
           }
           ?>
<HTML>
   <HEAD>
   <TITLE>Application Details</TITLE>
   </HEAD>
   <BODY>
   <H1>Here is your customer and application ID.� 
           You will need these to access your Loan Details</H1>
    <?php
           print "<p>Your Customer ID is: $cid</p>";
           print "<p>Your Application ID is: $aid</p>" ;
           print "<p>You should record these for future reference</p>";
    ?>
</BODY>
</HTML>